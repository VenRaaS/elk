package main

import "log"

func configureSyslog() {
  log.Printf("Logging to syslog not supported on this platform\n")
}
