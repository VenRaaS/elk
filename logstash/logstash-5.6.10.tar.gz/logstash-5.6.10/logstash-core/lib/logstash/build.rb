# encoding: utf-8
BUILD_INFO = {"build_date"=>"2018-06-06T17:22:55Z", "build_sha"=>"ec945d080a329375ae76b378c4c5d02a90602fc6", "build_snapshot"=>false}