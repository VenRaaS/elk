# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-10-06T21:56:03Z", "build_sha"=>"63a05c0bfbf08f7e46b93141a258b756339bbada", "build_snapshot"=>false}